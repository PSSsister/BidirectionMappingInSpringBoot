package com.example.ExampleApplication3.service;

import java.util.List;
import java.util.Optional;

import com.example.ExampleApplication3.bean.Customer;
import com.example.ExampleApplication3.exception.ResourceNotFoundException;


public interface ICustomer {

	public List<Customer> getAllCustomer();

	public Customer getCustomerById(int customerId);

	public String customerSignIn(String email, String phoneNo) throws ResourceNotFoundException;


}
