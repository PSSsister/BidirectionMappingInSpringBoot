package com.example.ExampleApplication3.bean;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Customer",uniqueConstraints=@UniqueConstraint(columnNames={"email", "phone_no"}))
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="customer_id")
    private int customerId;
	@Column(name="customer_name",nullable = false)
	private String customerName;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "address",referencedColumnName = "address_id")
	private Address address;
	
    @Column(name="email",nullable = false)
	private String email;
	@Column(name="age",nullable = false)
	private int age;
	@Column(name="phone_no",nullable = false)
	private String phoneNo;
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	/**
	 * 
	 */
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param customerId
	 * @param customerName
	 * @param address
	 * @param email
	 * @param age
	 * @param phoneNo
	 */
	public Customer(int customerId, String customerName, Address address, String email, int age, String phoneNo) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.address = address;
		this.email = email;
		this.age = age;
		this.phoneNo = phoneNo;
	}
	
	
}
