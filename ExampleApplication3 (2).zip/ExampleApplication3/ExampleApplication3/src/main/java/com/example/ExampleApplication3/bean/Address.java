package com.example.ExampleApplication3.bean;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="address_id",nullable = false)
    private int addressId;
	@Column(name="Street",nullable = false)
    private String Street;
	@Column(name="sector_no",nullable = false)
    private int sectorNo;
	@Column(name="pincode",nullable = false)
    private int pincode;
	
	@OneToMany(mappedBy = "address", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Customer> customer;

	       
	/**
	 * 
	 */
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	/**
	 * @param addressId
	 * @param street
	 * @param sectorNo
	 * @param pincode
	 * @param customer
	 */
	public Address(int addressId, String street, int sectorNo, int pincode, List<Customer> customer) {
		super();
		this.addressId = addressId;
		this.Street = street;
		this.sectorNo = sectorNo;
		this.pincode = pincode;
		this.customer =customer;
	}

	

	public int getAddressId() {
		return addressId;
	}

	/**
	 * @param addressId
	 * @param street
	 * @param sectorNo
	 * @param pincode
	 */
//	public Address(int addressId, String street, int sectorNo, int pincode) {
//		super();
//		this.addressId = addressId;
//		Street = street;
//		this.sectorNo = sectorNo;
//		this.pincode = pincode;
//	}


	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getStreet() {
		return Street;
	}

	public void setStreet(String street) {
		Street = street;
	}

	public int getSectorNo() {
		return sectorNo;
	}

	public void setSectorNo(int sectorNo) {
		this.sectorNo = sectorNo;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public List<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}
	
	
	
}
