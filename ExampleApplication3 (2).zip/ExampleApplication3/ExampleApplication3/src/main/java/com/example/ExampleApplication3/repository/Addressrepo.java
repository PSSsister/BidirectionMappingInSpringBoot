package com.example.ExampleApplication3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.ExampleApplication3.bean.Address;
import com.example.ExampleApplication3.bean.Customer;

@Repository
public interface Addressrepo extends JpaRepository<Address, Integer>{

}
