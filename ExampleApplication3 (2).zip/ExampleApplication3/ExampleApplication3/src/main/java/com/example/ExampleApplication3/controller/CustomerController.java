package com.example.ExampleApplication3.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.ExampleApplication3.bean.Customer;
import com.example.ExampleApplication3.service.ICustomer;


@RestController
//@RequestMapping("/*")
public class CustomerController {
	private Logger LOG = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	ICustomer customerservice;
	
	@GetMapping("/customer")
	public  List<Customer> fetchCustomer() 
	{
		return customerservice.getAllCustomer();
	}
	
	@GetMapping("/")
	public String print() {
		return "Hello World";
	}
	@GetMapping("/{customerId}")
	public Customer getId(@PathVariable Integer customerId) {
		return customerservice.getCustomerById(customerId);
	}
	@GetMapping("/customer/signin")
	public ResponseEntity<String> customerLogin(@RequestHeader MultiValueMap<String, String> headers,@RequestParam(value = "email",required = true) String email, @RequestParam(value = "phoneNo", required = true) String phoneNo) throws com.example.ExampleApplication3.exception.ResourceNotFoundException {
		headers.forEach((key, value) -> {
	        LOG.info(String.format(
	          "Header '%s' = %s", key, value.stream().collect(Collectors.joining())));
    });
		return new ResponseEntity<String>(customerservice.customerSignIn(email, phoneNo), HttpStatus.OK);
	}

	
	

}
