package com.example.ExampleApplication3.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ExampleApplication3.exception.ResourceNotFoundException;
import com.example.ExampleApplication3.bean.Address;
import com.example.ExampleApplication3.bean.Customer;
import com.example.ExampleApplication3.repository.Addressrepo;
import com.example.ExampleApplication3.repository.CustomerRepository;


@Service
public class ImplCustomer implements ICustomer {
	
	@Autowired
	CustomerRepository repository;
	
	@Autowired
	Addressrepo addressRepo;

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Customer getCustomerById(int customerId) {
		return repository.findById(customerId).map(customer -> {
			return customer;
		}).orElseThrow();
		// TODO Auto-generated method stub
	}

	@Override
	public String customerSignIn(String email, String phoneNo) throws ResourceNotFoundException {
		return repository.findByEmailAndPhoneNo(email,phoneNo).map(result -> {
            return "Login Successful";
        }).orElseThrow(() -> new ResourceNotFoundException("Customer with email " + email + " is not found in database."));
	}
	

}
