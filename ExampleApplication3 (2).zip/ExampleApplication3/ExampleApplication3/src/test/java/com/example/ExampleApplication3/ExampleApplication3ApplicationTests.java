package com.example.ExampleApplication3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleApplication3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
